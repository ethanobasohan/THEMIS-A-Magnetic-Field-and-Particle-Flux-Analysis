from cdflib import CDF
import numpy as np
import os

# --------------------------------------------------
# WEEK 2 THEMIS-A ANALYSIS
# July 1 - December 31, 2014
# --------------------------------------------------

# Find all FGM files
files = os.listdir(".")
fgm_files = sorted(
    f for f in files
    if f.endswith(".cdf") and "tha_l2_fgm_2014" in f
)

print("FGM files found:", len(fgm_files))

# Storage
all_time = []
all_bx = []
all_by = []
all_bz = []

# Read every FGM file
for filename in fgm_files:

    # Ignore empty files
    if os.path.getsize(filename) == 0:
        print("Skipping empty file:", filename)
        continue

    print("Reading:", filename)

    try:
        cdf = CDF(filename)

        time_data = np.asarray(
            cdf.varget("tha_fgs_time")
        ).reshape(-1)

        field_data = np.asarray(
            cdf.varget("tha_fgs_gsm")
        )

        all_time.append(time_data)
        all_bx.append(field_data[:, 0])
        all_by.append(field_data[:, 1])
        all_bz.append(field_data[:, 2])

    except Exception as error:
        print("Skipping unreadable file:", filename)
        print("Reason:", error)


# Combine all days
all_time = np.concatenate(all_time)
all_bx = np.concatenate(all_bx)
all_by = np.concatenate(all_by)
all_bz = np.concatenate(all_bz)


# Create M
# Column 0 = Time
# Column 1 = Bx
# Column 2 = By
# Column 3 = Bz

M = np.column_stack((
    all_time,
    all_bx,
    all_by,
    all_bz
))


# Display results
print()
print("FGM PROCESSING COMPLETE")
print("Rows in M:", M.shape[0])
print("Columns in M:", M.shape[1])

print()
print("First 5 rows of M:")
print(M[:5])

# --------------------------------------------------
# STEP 2: LOAD STATE POSITION DATA
# --------------------------------------------------

state_files = sorted(
    f for f in files
    if f.endswith(".cdf") and "tha_l1_state_2014" in f
)

print()
print("STATE files found:", len(state_files))

state_time = []
state_x = []
state_y = []
state_z = []

for filename in state_files:

    print("Reading STATE:", filename)

    try:
        cdf = CDF(filename)

        time_data = np.asarray(
            cdf.varget("tha_state_time")
        ).reshape(-1)

        position_data = np.asarray(
            cdf.varget("tha_pos_gsm")
        )

        state_time.append(time_data)
        state_x.append(position_data[:, 0])
        state_y.append(position_data[:, 1])
        state_z.append(position_data[:, 2])

    except Exception as error:
        print("Could not read:", filename)
        print("Reason:", error)


# Combine all STATE days

state_time = np.concatenate(state_time)
state_x = np.concatenate(state_x)
state_y = np.concatenate(state_y)
state_z = np.concatenate(state_z)

print()
print("STATE processing complete.")
print("STATE measurements:", len(state_time))


# --------------------------------------------------
# INTERPOLATE POSITION TO FGM TIMESTAMPS
# --------------------------------------------------

print()
print("Interpolating spacecraft position...")

X = np.interp(all_time, state_time, state_x)
Y = np.interp(all_time, state_time, state_y)
Z = np.interp(all_time, state_time, state_z)


# Add X, Y, Z to M

M = np.column_stack((
    all_time,
    all_bx,
    all_by,
    all_bz,
    X,
    Y,
    Z
))

print()
print("POSITION INTERPOLATION COMPLETE")
print("Rows in M:", M.shape[0])
print("Columns in M:", M.shape[1])

print()
print("Column structure:")
print("0 = Time")
print("1 = Bx")
print("2 = By")
print("3 = Bz")
print("4 = X")
print("5 = Y")
print("6 = Z")

print()
print("First 5 rows:")
print(M[:5])

# --------------------------------------------------
# STEP 3: APPLY RESTRICTIONS
# --------------------------------------------------

RE = 6300.0

# Individual restrictions
restriction_1 = X < (-6 * RE)
restriction_2 = np.abs(Y) < (np.abs(X) / 2)
restriction_3 = np.sqrt(all_bx**2 + all_by**2) < 15

# All three conditions must be true
restricted_mask = (
    restriction_1
    & restriction_2
    & restriction_3
)

# Create restricted matrix
M_restricted = M[restricted_mask]

print()
print("RESTRICTION PROCESSING COMPLETE")

print("Full data rows:", M.shape[0])
print("Restricted data rows:", M_restricted.shape[0])

print()
print("Restrictions used:")
print("X < -37800 km")
print("|Y| < |X| / 2")
print("sqrt(Bx^2 + By^2) < 15 nT")

print()
print("First 5 restricted rows:")
print(M_restricted[:5])

# --------------------------------------------------
# STEP 4: Bz STATISTICS AND HISTOGRAMS
# --------------------------------------------------

import matplotlib.pyplot as plt

# Bz is column 3 of M
bz_full = M[:, 3]
bz_restricted = M_restricted[:, 3]

# Remove any non-finite values
bz_full = bz_full[np.isfinite(bz_full)]
bz_restricted = bz_restricted[np.isfinite(bz_restricted)]


def print_statistics(name, data):
    print()
    print(name)
    print("Number of measurements:", len(data))
    print("Mean Bz:", np.mean(data), "nT")
    print("Median Bz:", np.median(data), "nT")
    print("Standard deviation:", np.std(data), "nT")
    print("Minimum Bz:", np.min(data), "nT")
    print("Maximum Bz:", np.max(data), "nT")


# Statistics
print_statistics("FULL SET Bz STATISTICS", bz_full)
print_statistics("RESTRICTED SET Bz STATISTICS", bz_restricted)


# --------------------------------------------------
# HISTOGRAMS
# Try different bin sizes: 50, 100, and 200
# --------------------------------------------------

for bins in [50, 100, 200]:

    # Full set - linear scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_full, bins=bins)
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Full Set Bz Histogram - {bins} Bins")
    plt.tight_layout()
    plt.savefig(f"bz_full_{bins}_bins_linear.png")
    plt.close()

        # Full set Bz - logarithmic histogram without extreme values
    bz_filtered = bz_full[(bz_full >= -100) & (bz_full <= 150)]

    plt.figure(figsize=(9, 6))
    plt.hist(bz_filtered, bins=bins)
    plt.yscale("log")
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements (Log Scale)")
    plt.title(f"Full Set Bz Histogram - Filtered - {bins} Bins")
    plt.tight_layout()
    plt.savefig(f"bz_full_filtered_{bins}_bins_log.png", dpi=200)
    plt.close()

    

    # Full set - logarithmic scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_full, bins=bins)
    plt.yscale("log")
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements (Log Scale)")
    plt.title(f"Full Set Bz Histogram - {bins} Bins - Log Scale")
    plt.tight_layout()
    plt.savefig(f"bz_full_{bins}_bins_log.png")
    plt.close()

    # Restricted set - linear scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_restricted, bins=bins)
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Restricted Set Bz Histogram - {bins} Bins")
    plt.tight_layout()
    plt.savefig(f"bz_restricted_{bins}_bins_linear.png")
    plt.close()

    # Restricted set - logarithmic scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_restricted, bins=bins)
    plt.yscale("log")
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements (Log Scale)")
    plt.title(f"Restricted Set Bz Histogram - {bins} Bins - Log Scale")
    plt.tight_layout()
    plt.savefig(f"bz_restricted_{bins}_bins_log.png")
    plt.close()

    # Full set - zoomed logarithmic histogram
plt.figure(figsize=(9, 6))

plt.hist(bz_full, bins=bins, range=(-100, 150))

plt.yscale("log")
plt.xlabel("Bz (nT)")
plt.ylabel("Number of Measurements (Log Scale)")
plt.title(f"Full Set Bz Histogram - Zoomed - {bins} Bins")

plt.tight_layout()
plt.savefig(f"bz_full_zoomed_{bins}_bins_log.png", dpi=200)
plt.close()


print()
print("Bz HISTOGRAMS COMPLETE")
print("Histogram images saved in the current folder.")

# --------------------------------------------------
# STEP 5: CALCULATE dBz6sec
# --------------------------------------------------

# Create empty dBz6sec array
dBz6sec = np.full(len(M), np.nan)

# Supervisor's formula:
# dBz6sec(i) = Bz(i+1) - Bz(i-1)
dBz6sec[1:-1] = M[2:, 3] - M[:-2, 3]

# Check the actual time span between i-1 and i+1.
# If there is a large data gap, do not treat it as a 6-second change.
time_span = M[2:, 0] - M[:-2, 0]
valid_6sec = (time_span >= 4) & (time_span <= 8)

middle_values = dBz6sec[1:-1]
middle_values[~valid_6sec] = np.nan
dBz6sec[1:-1] = middle_values

# Add dBz6sec as column 8
M = np.column_stack((M, dBz6sec))

M_restricted = M[restricted_mask]

print("Updated restricted matrix:", M_restricted.shape)

print()
print("dBz6sec CALCULATION COMPLETE")
print("Rows in M:", M.shape[0])
print("Columns in M:", M.shape[1])
print("Valid dBz6sec measurements:", np.sum(np.isfinite(dBz6sec)))

print()
print("Column structure:")
print("0 = Time")
print("1 = Bx")
print("2 = By")
print("3 = Bz")
print("4 = X")
print("5 = Y")
print("6 = Z")
print("7 = dBz6sec")

# --------------------------------------------------
# STEP 6: ANALYZE dBz6sec
# --------------------------------------------------

# Valid full-set dBz6sec values
dbz_full = dBz6sec[np.isfinite(dBz6sec)]

# Restricted-set dBz6sec values
dbz_restricted = dBz6sec[restricted_mask]
dbz_restricted = dbz_restricted[np.isfinite(dbz_restricted)]

print()
print("FULL SET dBz6sec STATISTICS")
print("Number of measurements:", len(dbz_full))
print("Mean:", np.mean(dbz_full), "nT")
print("Median:", np.median(dbz_full), "nT")
print("Standard deviation:", np.std(dbz_full), "nT")
print("Minimum:", np.min(dbz_full), "nT")
print("Maximum:", np.max(dbz_full), "nT")

print()
print("RESTRICTED SET dBz6sec STATISTICS")
print("Number of measurements:", len(dbz_restricted))
print("Mean:", np.mean(dbz_restricted), "nT")
print("Median:", np.median(dbz_restricted), "nT")
print("Standard deviation:", np.std(dbz_restricted), "nT")
print("Minimum:", np.min(dbz_restricted), "nT")
print("Maximum:", np.max(dbz_restricted), "nT")


# --------------------------------------------------
# dBz6sec vs time
# --------------------------------------------------

# Downsample for plotting only.
# Statistics above still use every valid measurement.
plot_step = 30

valid_plot = np.isfinite(dBz6sec[::plot_step])

plt.figure(figsize=(40, 20))
plt.plot(
    all_time[::plot_step][valid_plot],
    dBz6sec[::plot_step][valid_plot],
    linewidth=0.5
)

plt.xlabel("Time")
plt.ylabel("dBz6sec (nT)")
plt.title("THEMIS-A dBz6sec vs Time: July-December 2014")
plt.tight_layout()
plt.savefig("dBz6sec_vs_updated_time.png", dpi=200)
plt.close()


# --------------------------------------------------
# dBz6sec HISTOGRAMS
# --------------------------------------------------

for bins in [50, 100, 200]:

    # Full set - linear
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_full, bins=bins)
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count")
    plt.title(f"Full Set dBz6sec Histogram ({bins} bins)")
    plt.tight_layout()
    plt.savefig(f"dBz_full_linear_{bins}bins.png", dpi=200)
    plt.close()

        # Full set - zoomed linear histogram
    plt.figure(figsize=(9, 6))

    plt.hist(bz_full, bins=bins, range=(-100, 150))

    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Full Set Bz Histogram - Zoomed - {bins} Bins")

    plt.tight_layout()
    plt.savefig(f"bz_full_zoomed_{bins}_bins_linear.png", dpi=200)
    plt.close()

        # Full set dBz6sec - zoomed linear histogram
    plt.figure(figsize=(8, 5))

    plt.hist(dbz_full, bins=bins, range=(-5, 5))

    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Full Set dBz6sec Histogram - Zoomed ({bins} bins)")

    plt.tight_layout()
    plt.savefig(f"dBz_full_zoomed_linear_{bins}bins.png", dpi=200)
    plt.close()

    # Full set - logarithmic count
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_full, bins=bins)
    plt.yscale("log")
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count (log scale)")
    plt.title(f"Full Set dBz6sec Histogram - Log Scale ({bins} bins)")
    plt.tight_layout()
    plt.savefig(f"dBz_full_log_{bins}bins.png", dpi=200)
    plt.close()

    # Restricted set - linear
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_restricted, bins=bins)
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count")
    plt.title(f"Restricted Set dBz6sec Histogram ({bins} bins)")
    plt.tight_layout()
    plt.savefig(f"dBz_restricted_linear_{bins}bins.png", dpi=200)
    plt.close()

    # Restricted set - logarithmic count
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_restricted, bins=bins)
    plt.yscale("log")
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count (log scale)")
    plt.title(
        f"Restricted Set dBz6sec Histogram - Log Scale ({bins} bins)"
    )
    plt.tight_layout()
    plt.savefig(f"dBz_restricted_log_{bins}bins.png", dpi=200)
    plt.close()

print()
print("dBz6sec ANALYSIS COMPLETE")
print("Plot and histogram images saved in the current folder.")

# ============================================================
# STEP 7: LOAD SST DATA (JULY–DECEMBER 2014)
# ============================================================

sst_files = sorted(
    f for f in os.listdir(".")
    if f.startswith("tha_l2_sst_2014") and f.endswith(".cdf")
)

print("\nSST files found:", len(sst_files))

ion_times = []
ion_fluxes = []

electron_times = []
electron_fluxes = []

for filename in sst_files:
    print("Reading SST:", filename)

    cdf = CDF(filename)

    ion_time = np.asarray(cdf.varget("tha_psif_time")).reshape(-1)
    electron_time = np.asarray(cdf.varget("tha_psef_time")).reshape(-1)

    # Ion channel 4: approximately 106 keV
    ion_flux = np.asarray(
        cdf.varget("tha_psif_en_eflux")
    )[:, 3]

    # Electron channel 5: approximately 93 keV
    electron_flux = np.asarray(
        cdf.varget("tha_psef_en_eflux")
    )[:, 4]

    ion_times.append(ion_time)
    ion_fluxes.append(ion_flux)

    electron_times.append(electron_time)
    electron_fluxes.append(electron_flux)

ion_times = np.concatenate(ion_times)
ion_fluxes = np.concatenate(ion_fluxes)

electron_times = np.concatenate(electron_times)
electron_fluxes = np.concatenate(electron_fluxes)

print("\nSST PROCESSING COMPLETE")
print("Total ion measurements:", len(ion_fluxes))
print("Total electron measurements:", len(electron_fluxes))

# ============================================================
# STEP 8: CALCULATE SST dF WITH GAP CHECKS
# ============================================================

def calculate_df(times, flux):
    # Sort measurements by timestamp
    order = np.argsort(times)
    times = times[order]
    flux = flux[order]

    dF = np.full(len(flux), np.nan)

    # Difference between neighboring measurements
    difference = flux[2:] - flux[:-2]

    # Check for gaps using the normal SST cadence (~2.927 sec)
    previous_gap = times[1:-1] - times[:-2]
    next_gap = times[2:] - times[1:-1]

    valid = (
        (previous_gap > 0) &
        (previous_gap <= 6) &
        (next_gap > 0) &
        (next_gap <= 6) &
        np.isfinite(flux[:-2]) &
        np.isfinite(flux[2:])
    )

    middle = dF[1:-1]
    middle[valid] = difference[valid]
    dF[1:-1] = middle

    return times, dF


ion_times, ion_dF = calculate_df(ion_times, ion_fluxes)
electron_times, electron_dF = calculate_df(
    electron_times, electron_fluxes
)

print("\nSIX-MONTH dF CALCULATION COMPLETE")
print("Valid ion dF:", np.sum(np.isfinite(ion_dF)))
print("Valid electron dF:", np.sum(np.isfinite(electron_dF)))

# ============================================================
# STEP 9: INTERPOLATE dF INTO RESTRICTED MATRIX
# ============================================================

def interpolate_df(target_times, source_times, source_df):
    result = np.full(len(target_times), np.nan)

    valid = (
        np.isfinite(source_times) &
        np.isfinite(source_df)
    )

    t = source_times[valid]
    values = source_df[valid]

    # Interpolate only between neighboring valid measurements
    # that are sufficiently close in time.
    if len(t) < 2:
        return result

    order = np.argsort(t)
    t = t[order]
    values = values[order]

    right = np.searchsorted(t, target_times, side="left")
    left = right - 1

    inside = (left >= 0) & (right < len(t))

    indices = np.where(inside)[0]
    li = left[indices]
    ri = right[indices]

    gap = t[ri] - t[li]

    # Allow up to 6 seconds between valid SST samples
    good = (gap > 0) & (gap <= 6)

    indices = indices[good]
    li = li[good]
    ri = ri[good]

    fraction = (
        (target_times[indices] - t[li]) /
        (t[ri] - t[li])
    )

    result[indices] = (
        values[li] +
        fraction * (values[ri] - values[li])
    )

    # Preserve exact timestamp matches
    exact = np.searchsorted(t, target_times)
    exact_valid = exact < len(t)
    exact_rows = np.where(exact_valid)[0]
    exact_indices = exact[exact_rows]

    matches = t[exact_indices] == target_times[exact_rows]

    result[exact_rows[matches]] = values[exact_indices[matches]]

    return result


restricted_times = M_restricted[:, 0]

ion_dF_interpolated = interpolate_df(
    restricted_times, ion_times, ion_dF
)

electron_dF_interpolated = interpolate_df(
    restricted_times, electron_times, electron_dF
)

M_restricted = np.column_stack((
    M_restricted,
    ion_dF_interpolated,
    electron_dF_interpolated
))

print("\nWEEK 3 TASK 1 INTERPOLATION COMPLETE")
print("Restricted matrix shape:", M_restricted.shape)
print("Valid interpolated ion dF:",
      np.sum(np.isfinite(M_restricted[:, 8])))
print("Valid interpolated electron dF:",
      np.sum(np.isfinite(M_restricted[:, 9])))

# ============================================================
# STEP 10: 2D COLOR MAP OF Bz VS dBz6sec
# ============================================================

from matplotlib.colors import LogNorm

# Extract restricted measurements
bz = M_restricted[:, 3]
dbz = M_restricted[:, 7]

# Keep only finite values
valid = np.isfinite(bz) & np.isfinite(dbz)

bz = bz[valid]
dbz = dbz[valid]

plt.figure(figsize=(10, 7))

plt.hist2d(
    bz,
    dbz,
    bins=100,
    norm=LogNorm(),
    cmap="viridis",
    cmin=5
)

plt.xlim(left=0)

plt.colorbar(label="Number of measurements per bin")

plt.xlabel("Bz (nT)")
plt.ylabel("dBz6sec (nT)")
plt.title("THEMIS-A: Bz vs dBz6sec (Restricted Data, Jul–Dec 2014)")

plt.tight_layout()
plt.savefig("week3_Bz_vs_dBz6sec_2D.png", dpi=300)
plt.close()

print("\nWEEK 3 TASK 2 COMPLETE")
print("Valid measurements plotted:", len(bz))
print("Saved: week3_Bz_vs_dBz6sec_2D.png")


# Focused magnetic field plot
plt.figure(figsize=(10, 6))

plt.hist2d(
    M_restricted[:, 3],
    M_restricted[:, 7],
    bins=100,
    range=[[0, 30], [-10, 10]],
    norm=LogNorm(),
    cmap="viridis",
    cmin=5
)

plt.xlim(left=0)

plt.colorbar(label="Number of measurements per bin")
plt.xlabel("Bz (nT)")
plt.ylabel("dBz6sec (nT)")
plt.title("THEMIS-A: Focused Bz vs dBz6sec (Restricted Data)")

plt.tight_layout()
plt.savefig("week3_Bz_vs_dBz6sec_focused.png", dpi=300)
plt.show()


# ============================================================
# STEP 11: CALCULATE RELATIVE FLUX CHANGES
# ============================================================

def calculate_relative_change(times, flux):
    order = np.argsort(times)
    times = times[order]
    flux = flux[order]

    relative = np.full(len(flux), np.nan)

    previous = flux[:-2]
    following = flux[2:]

    dF = following - previous
    average_F = (following + previous) / 2

    previous_gap = times[1:-1] - times[:-2]
    next_gap = times[2:] - times[1:-1]

    valid = (
        (previous_gap > 0) &
        (previous_gap <= 6) &
        (next_gap > 0) &
        (next_gap <= 6) &
        np.isfinite(previous) &
        np.isfinite(following) &
        (previous >= 0) &
        (following >= 0) &
        (average_F > 0)
    )

    middle = relative[1:-1]
    middle[valid] = dF[valid] / average_F[valid]
    relative[1:-1] = middle

    return times, relative


ion_times, ion_relative = calculate_relative_change(
    ion_times, ion_fluxes
)

electron_times, electron_relative = calculate_relative_change(
    electron_times, electron_fluxes
)

print("\nWEEK 3 RELATIVE CHANGE CALCULATION COMPLETE")
print("Valid ion relative changes:",
      np.sum(np.isfinite(ion_relative)))
print("Valid electron relative changes:",
      np.sum(np.isfinite(electron_relative)))

# ============================================================
# STEP 12: INTERPOLATE RELATIVE FLUX CHANGES
# ============================================================

ion_relative_interpolated = interpolate_df(
    restricted_times,
    ion_times,
    ion_relative
)

electron_relative_interpolated = interpolate_df(
    restricted_times,
    electron_times,
    electron_relative
)

# Add both relative changes to the restricted matrix
M_restricted = np.column_stack((
    M_restricted,
    ion_relative_interpolated,
    electron_relative_interpolated
))

print("\nWEEK 3 STEP 12 COMPLETE")
print("Restricted matrix shape:", M_restricted.shape)
print("Valid ion relative changes:",
      np.sum(np.isfinite(M_restricted[:, 10])))
print("Valid electron relative changes:",
      np.sum(np.isfinite(M_restricted[:, 11])))

# ============================================================
# STEP 13: 2D COLOR MAP OF RELATIVE FLUX CHANGES
# ============================================================

ion_relative_plot = M_restricted[:, 10]
electron_relative_plot = M_restricted[:, 11]

# Keep measurements where both values are valid
valid = (
    np.isfinite(ion_relative_plot) &
    np.isfinite(electron_relative_plot)
)

ion_relative_plot = ion_relative_plot[valid]
electron_relative_plot = electron_relative_plot[valid]

plt.figure(figsize=(10, 7))

plt.hist2d(
    ion_relative_plot,
    electron_relative_plot,
    bins=100,
    range=[[-2, 2], [-2, 2]],
    norm=LogNorm(),
    cmap="viridis",
    cmin=5
)

plt.xlim(left=0)

plt.colorbar(label="Number of measurements per bin")

plt.xlabel("Relative ion flux change (PSIF), dF/<F>")
plt.ylabel("Relative electron flux change (PSEF), dF/<F>")

plt.title(
    "THEMIS-A: Relative Ion vs Electron Flux Changes\n"
    "Restricted Data, July–December 2014"
)

plt.tight_layout()

plt.savefig(
    "week3_ion_vs_electron_relative_change_2D.png",
    dpi=300
)

plt.close()

print("\nWEEK 3 TASK 3 COMPLETE")
print("Valid paired measurements plotted:", len(ion_relative_plot))
print("Saved: week3_ion_vs_electron_relative_change_2D.png")


# Focused particle flux plot
plt.figure(figsize=(10, 6))

plt.hist2d(
    M_restricted[:, 10],
    M_restricted[:, 11],
    bins=100,
    range=[[-0.5, 0.5], [-0.5, 0.5]],
    norm=LogNorm(),
    cmap="viridis",
    cmin=5
)

plt.xlim(left=0)

plt.colorbar(label="Number of measurements per bin")
plt.xlabel("Relative ion flux change (PSIF)")
plt.ylabel("Relative electron flux change (PSEF)")
plt.title("THEMIS-A: Focused Relative Ion vs Electron Flux Changes")

plt.tight_layout()
plt.savefig("week3_ion_vs_electron_relative_change_focused.png", dpi=300)
plt.show()